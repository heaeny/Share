#include "KUnityParse.h"


int main()
{
	KUnityParse::instance()->init();

	return 0;
}