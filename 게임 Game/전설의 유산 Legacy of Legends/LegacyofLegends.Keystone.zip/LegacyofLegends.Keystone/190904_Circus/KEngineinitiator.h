#pragma once
#include "KCore.h"

class KEngineinitiator 
{
public:
	KEngineinitiator();
	~KEngineinitiator() ;

public:
	bool init() ;
};

