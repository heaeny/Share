#pragma once

class KEngineReleaser 
{
public:
	KEngineReleaser();
	~KEngineReleaser();

public:
	void release() ;
};

