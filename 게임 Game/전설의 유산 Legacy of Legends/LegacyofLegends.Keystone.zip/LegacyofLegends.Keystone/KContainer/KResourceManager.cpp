#include "KResourceManager.h"
