#include "KFileStream.h"

KFileStream* KFileStream::pKFileStream = nullptr;