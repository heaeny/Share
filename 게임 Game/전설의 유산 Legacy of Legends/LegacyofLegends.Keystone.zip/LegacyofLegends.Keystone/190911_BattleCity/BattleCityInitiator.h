#pragma once
class BattleCityInitiator
{
public:
	BattleCityInitiator();
	~BattleCityInitiator();

public:
	bool init();
};

