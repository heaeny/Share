#pragma once

#include "resource.h"


#define WINXSIZE (600)
#define WINYSIZE (600)