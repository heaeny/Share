#include "KActor.h"



KActor::KActor() : bActing(true), bNextActing(true), bDeath(false)
{

}


KActor::~KActor()
{

}