#include "KUpdater.h"



KUpdater::KUpdater()
{
}


KUpdater::~KUpdater()
{
}
