#include "KComponent.h"



KComponent::KComponent()
{
}