#include "KProgress.h"

KProgress::KProgress()
{
}


KProgress::~KProgress()
{
}
