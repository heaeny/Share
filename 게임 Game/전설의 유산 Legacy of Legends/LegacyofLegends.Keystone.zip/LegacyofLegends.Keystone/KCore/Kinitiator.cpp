#include "KInitiator.h"



KInitiator::KInitiator()
{
}


KInitiator::~KInitiator()
{
}
