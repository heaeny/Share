#include "KName.h"



KName::KName() :sName(L"name")
{
}


KName::~KName()
{
}