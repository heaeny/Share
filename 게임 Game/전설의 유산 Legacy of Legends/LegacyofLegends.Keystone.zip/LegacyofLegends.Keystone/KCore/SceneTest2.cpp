#include "SceneTest2.h"



SceneTest2::SceneTest2()
{
}


SceneTest2::~SceneTest2()
{
}


void SceneTest2::update() 
{

}