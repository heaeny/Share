#include "Transform.h"



Transform::Transform()
{
}


Transform::~Transform()
{
}



bool Transform::init()
{
	return true;
}
void Transform::update()
{

}
void Transform::release()
{

}
