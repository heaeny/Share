#pragma once
#include "KScene.h"
class SceneTest2 : public KScene
{
public:
	SceneTest2();
	~SceneTest2();


public:
	void update() override;
};

