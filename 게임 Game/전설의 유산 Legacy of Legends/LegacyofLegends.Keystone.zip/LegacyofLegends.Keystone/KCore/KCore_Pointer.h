#pragma once




class KCore_Pointer
{
public:
	KCore_Pointer() {};
	~KCore_Pointer() {};
};

