#include "KReleaser.h"


KReleaser::KReleaser()
{
}


KReleaser::~KReleaser()
{
}
