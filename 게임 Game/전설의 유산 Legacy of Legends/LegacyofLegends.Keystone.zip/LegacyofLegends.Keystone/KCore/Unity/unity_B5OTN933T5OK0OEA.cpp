
#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\ComTest.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KVector.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KUpdater.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KTransform.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KTimeManager.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KSceneManager.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KScene.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KRenderManager.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KRenderer.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KReleaser.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KProgress.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KPathManager.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KOne.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KName.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KInputManager.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\Kinitiator.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KEngineUpdater.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KEngineLauncher.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KEngineinitiator.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KCore_Pointer.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KCore.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KConsole_Render.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KComponent.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\KActor.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\SceneTest.cpp"


#include "C:\TTmp\NeoAcademy\KClass_Git\KEngine2_0\KCore\Transform.cpp"

