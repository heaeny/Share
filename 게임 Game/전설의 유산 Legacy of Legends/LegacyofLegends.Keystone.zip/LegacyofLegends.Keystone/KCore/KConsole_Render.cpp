#include "KConsole_Render.h"



KConsole_Render::KConsole_Render()
{
}


KConsole_Render::~KConsole_Render()
{
}


void KConsole_Render::create()
{
	sName = L"KConsole_Render";
}

bool KConsole_Render::init()
{
	return true;
}
void KConsole_Render::render()
{

}